import { useEffect, useRef, useState } from "react";
import {
  bookmarkMessage,
  checkBookmark,
  removeBookmark,
  votePoll,
  getPoll,
} from "../../../services/chatService";

function ChatWindow({ messages, currentUserId, onVoteRefresh }) {
  const bottomRef = useRef(null);
  const [bookmarks, setBookmarks] = useState({});
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    const loadBookmarks = async () => {
      const result = {};
      for (const message of messages) {
        try {
          result[message._id] = await checkBookmark(message._id);
        } catch {
          result[message._id] = false;
        }
      }
      setBookmarks(result);
    };

    if (messages.length) loadBookmarks();
  }, [messages]);

  const toggleBookmark = async (messageId) => {
    try {
      if (bookmarks[messageId]) {
        await removeBookmark(messageId);
        setBookmarks((prev) => ({ ...prev, [messageId]: false }));
      } else {
        await bookmarkMessage(messageId);
        setBookmarks((prev) => ({ ...prev, [messageId]: true }));
      }
    } catch (error) {
      alert(error.response?.data?.message || "Bookmark failed");
    }
  };

  if (!messages.length) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-400">
        No messages yet. Say hello 👋
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-5 bg-[#f7f8fc]">
      <div className="max-w-4xl mx-auto space-y-3">
        {messages.map((message) => {
          const mine =
            String(message.sender?._id || message.sender) ===
            String(currentUserId);

          return (
            <div
              key={message._id}
              className={`flex ${mine ? "justify-end" : "justify-start"}`}
            >
              <div className="relative max-w-[75%]">
                <div
                  className={`rounded-2xl px-4 py-3 shadow-sm ${
                    mine
                      ? "bg-indigo-600 text-white rounded-br-sm"
                      : "bg-white text-gray-800 rounded-bl-sm"
                  }`}
                >
                  <MessageContent message={message} />

                  <div
                    className={`mt-1 text-[10px] ${
                      mine ? "text-indigo-100" : "text-gray-400"
                    }`}
                  >
                    {message.createdAt
                      ? new Date(message.createdAt).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })
                      : ""}

                    {mine && (
                      <span className="ml-2">
                        {message.isRead ? "✓✓" : message.isDelivered ? "✓✓" : "✓"}
                      </span>
                    )}

                    {message.isSelfDestruct && (
                      <span className="ml-2">💣 {getExpiryText(message)}</span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() =>
                    setOpenMenu(
                      openMenu === message._id ? null : message._id
                    )
                  }
                  className="absolute -right-8 top-1 text-gray-400"
                >
                  ⋮
                </button>

                {openMenu === message._id && (
                  <div className="absolute right-0 top-8 z-20 bg-white border rounded-lg shadow-lg p-1 min-w-36">
                    <button
                      onClick={() => toggleBookmark(message._id)}
                      className="w-full text-left px-3 py-2 hover:bg-gray-100"
                    >
                      {bookmarks[message._id]
                        ? "⭐ Remove bookmark"
                        : "☆ Bookmark"}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        <div ref={bottomRef} />
      </div>
    </div>
  );
}

function MessageContent({ message }) {
  if (message.messageType === "image" && message.image) {
    return (
      <img
        src={message.image}
        alt="attachment"
        className="max-w-full max-h-80 rounded-xl"
      />
    );
  }

  if (message.messageType === "audio" && message.audio) {
    return <audio controls src={message.audio} className="max-w-full" />;
  }

  return <p className="whitespace-pre-wrap break-words">{message.text}</p>;
}

function getExpiryText(message) {
  if (!message.expiresAt) return "self-destruct";
  const seconds = Math.max(
    0,
    Math.round((new Date(message.expiresAt) - Date.now()) / 1000)
  );
  return seconds > 0 ? `${seconds}s` : "expired";
}

export default ChatWindow;
