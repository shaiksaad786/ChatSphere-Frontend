import { useEffect, useState } from "react";

import {
  addBookmark,
  removeBookmark,
  checkBookmark,
} from "../../../services/bookmarkService";

function BookmarkButton({ messageId }) {
  const [bookmarked, setBookmarked] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (messageId) {
      loadBookmarkStatus();
    }
  }, [messageId]);

  const loadBookmarkStatus = async () => {
    try {
      const response = await checkBookmark(messageId);

      setBookmarked(
        response?.bookmarked ||
          response?.isBookmarked ||
          false
      );
    } catch (error) {
      console.error("Bookmark check failed:", error);
    }
  };

  const toggleBookmark = async () => {
    try {
      setLoading(true);

      if (bookmarked) {
        await removeBookmark(messageId);
        setBookmarked(false);
      } else {
        await addBookmark(messageId);
        setBookmarked(true);
      }
    } catch (error) {
      console.error("Bookmark error:", error);

      alert(
        error?.response?.data?.message ||
          "Bookmark operation failed."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={toggleBookmark}
      disabled={loading}
      title={
        bookmarked
          ? "Remove bookmark"
          : "Bookmark message"
      }
      className="text-lg hover:scale-110 transition"
    >
      {bookmarked ? "🔖" : "🏷️"}
    </button>
  );
}

export default BookmarkButton;