import { useEffect, useMemo, useState } from "react";
import { io } from "socket.io-client";
import ConversationList from "../components/auth/chat/ConversationList";
import ChatHeader from "../components/auth/chat/ChatHeader";
import ChatWindow from "../components/auth/chat/ChatWindow";
import MessageInput from "../components/auth/chat/MessageInput";
import AIAssistant from "../components/auth/ai/AIAssistant";
import PollModal from "../components/auth/features/PollModal";
import ToolsPanel from "../components/auth/features/ToolsPanel";
import {
  getConversations,
  getMessages,
  markMessagesRead,
} from "../services/chatService";

const SOCKET_URL = "http://localhost:3000";

function Chat() {
  const [conversations, setConversations] = useState([]);
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [pollOpen, setPollOpen] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState({});
  const [typing, setTyping] = useState(false);

  const currentUserId = useMemo(getCurrentUserId, []);

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (!currentUserId) return;

    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
    });

    socket.on("connect", () => {
      socket.emit("join", currentUserId);
    });

    socket.on("newMessage", (message) => {
      setMessages((prev) => {
        if (prev.some((item) => item._id === message._id)) return prev;

        if (
          selected &&
          String(message.conversation) === String(selected._id)
        ) {
          return [...prev, message];
        }

        return prev;
      });

      loadConversations();
    });

    socket.on("deliveryReceipt", ({ messageId }) => {
      setMessages((prev) =>
        prev.map((m) =>
          m._id === messageId
            ? { ...m, isDelivered: true }
            : m
        )
      );
    });

    socket.on("readReceipt", ({ messageId }) => {
      setMessages((prev) =>
        prev.map((m) =>
          m._id === messageId ? { ...m, isRead: true } : m
        )
      );
    });

    socket.on("messageExpired", ({ messageId }) => {
      setMessages((prev) =>
        prev.filter((m) => String(m._id) !== String(messageId))
      );
    });

    socket.on("userOnline", ({ userId }) => {
      setOnlineUsers((prev) => ({ ...prev, [userId]: true }));
    });

    socket.on("userOffline", ({ userId }) => {
      setOnlineUsers((prev) => ({ ...prev, [userId]: false }));
    });

    socket.on("typing", ({ senderId }) => {
      if (
        selected?.participants?.some(
          (p) => String(p._id) === String(senderId)
        )
      ) {
        setTyping(true);
      }
    });

    socket.on("stopTyping", () => setTyping(false));

    return () => socket.disconnect();
  }, [currentUserId, selected]);

  const loadConversations = async () => {
    try {
      const data = await getConversations();
      setConversations(data);

      if (!selected && data.length > 0) {
        await selectConversation(data[0]);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoadingConversations(false);
    }
  };

  const selectConversation = async (conversation) => {
    setSelected(conversation);
    setAiOpen(false);
    setToolsOpen(false);
    setLoadingMessages(true);

    try {
      const data = await getMessages(conversation._id);
      setMessages(data);
      await markMessagesRead(conversation._id).catch(() => {});
    } catch (error) {
      console.error(error);
      setMessages([]);
    } finally {
      setLoadingMessages(false);
    }
  };

  const addSentMessage = (message) => {
    setMessages((prev) => {
      if (prev.some((item) => item._id === message._id)) return prev;
      return [...prev, message];
    });
    loadConversations();
  };

  const online = selected
    ? selected.participants?.some(
        (p) =>
          String(p._id) !== String(currentUserId) &&
          onlineUsers[String(p._id)]
      )
    : false;

  return (
    <div className="h-screen flex bg-gray-100 overflow-hidden">
      <div className="hidden lg:block">
      </div>

      <ConversationList
        conversations={conversations}
        selectedId={selected?._id}
        onSelect={selectConversation}
        loading={loadingConversations}
      />

      <main className="flex-1 min-w-0 flex flex-col">
        <ChatHeader conversation={selected} online={online} />

        {loadingMessages ? (
          <div className="flex-1 flex items-center justify-center">
            Loading messages...
          </div>
        ) : (
          <ChatWindow
            messages={messages}
            currentUserId={currentUserId}
          />
        )}

        {typing && (
          <div className="px-5 py-1 text-xs text-gray-500">
            Someone is typing...
          </div>
        )}

        <div className="flex items-center gap-2 px-3 bg-white">
          <button
            onClick={() => setPollOpen(true)}
            disabled={!selected}
            className="p-2 rounded-lg hover:bg-gray-100"
            title="Create poll"
          >
            📊
          </button>

          <button
            onClick={() => setToolsOpen(!toolsOpen)}
            className="p-2 rounded-lg hover:bg-gray-100"
            title="Bookmarks and scheduled messages"
          >
            ⭐
          </button>
        </div>

        <MessageInput
          conversation={selected}
          onMessageSent={addSentMessage}
          onOpenAI={() => setAiOpen(true)}
        />
      </main>

      {aiOpen && (
        <AIAssistant
          messages={messages}
          onUseReply={(reply) => {
            window.dispatchEvent(
              new CustomEvent("chatsphere-use-reply", {
                detail: reply,
              })
            );
          }}
          onClose={() => setAiOpen(false)}
        />
      )}

      {toolsOpen && <ToolsPanel onClose={() => setToolsOpen(false)} />}

      {pollOpen && selected && (
        <PollModal
          conversationId={selected._id}
          onClose={() => setPollOpen(false)}
          onCreated={() => {
            alert("Poll created. Refresh/open the chat to see it.");
          }}
        />
      )}
    </div>
  );
}

function getCurrentUserId() {
  try {
    const token = localStorage.getItem("token");
    if (!token) return null;
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.id || payload._id || payload.userId;
  } catch {
    return null;
  }
}

export default Chat;
