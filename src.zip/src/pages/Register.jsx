import RegisterForm from "../components/auth/RegisterForm";
function Register(){
    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center">
            <RegisterForm />
        </div>
    );
}
export default Register;